int* solGreedy(int[][3], int, int, int, int, int, bool);

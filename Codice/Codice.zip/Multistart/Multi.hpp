void solMulti(int[][3], int, int, int, string, string, string, bool);
